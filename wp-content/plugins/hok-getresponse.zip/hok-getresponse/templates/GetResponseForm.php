<div class="getGetResponseForm">
    <form method="post" data-name="%formname%">
        <div class="form-group">
            <input type="email" class="form-control">
        </div>
        <div class="form-group">
            <button type="submit">Zapisz mnie</button>
        </div>
    </form>
    <div id="getGetResponseMsg" style="display: none"></div>
</div>